
package desafio01;

public abstract class Colaborador {
    
public abstract void Cadastrar();


}
