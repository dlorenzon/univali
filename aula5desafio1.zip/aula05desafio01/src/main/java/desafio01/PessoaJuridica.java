
package desafio01;

public class PessoaJuridica extends Colaborador {
     
    String razãosocial;
    String nomefantasia;
    int inscricaomunicipal;
    int inscriçãoestadual;
    String CNPJ;
    String logradouro;
    int número;
    String bairro;
    String cidade;
    String UF;
    int telefone;
    String email;
    String website;
    String disciplinasministra;
    
    public void Cadastrar() {
       this.razãosocial = razãosocial;
       this.nomefantasia = nomefantasia;
       this.inscricaomunicipal = inscricaomunicipal;
       this.inscriçãoestadual = inscriçãoestadual;
       this.logradouro = logradouro;
       this.número = número;
       this.bairro = bairro;
       this.cidade = cidade;
       this.UF = UF;
       this.telefone = telefone;
       this.email = email;
       this.CNPJ = CNPJ;
       this.disciplinasministra = disciplinasministra;
            
        
    }    
          
}
