
package desafio01;

public class PessoaFisica extends Colaborador {
    
    String Nome;
    String CPF;
    String RG;
    int idade;
    String logradouro;
    int numero;
    String bairro;
    String cidade;
    String UF;
    int telefone;
    String email;
    String titulação;
    String disciplinasministra;
    
    @Override
    public void Cadastrar(){
    this.Nome = Nome;
    
    }
}