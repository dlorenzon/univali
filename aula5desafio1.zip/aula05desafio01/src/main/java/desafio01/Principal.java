
package desafio01;


public class Principal {

    public static void main(String[] args) {

    PessoaFisica Daniel = new PessoaFisica();
    Daniel.CPF = "982798237-98";
    Daniel.Nome = "Daniel";
    
    PessoaJuridica Mei = new PessoaJuridica();
    Mei.CNPJ = "98276156165166d8";
    Mei.razãosocial = "Daniel treinamentos";
    
    System.out.println("Nome PF" + Daniel.Nome);

    System.out.println("Nome PJ" + Mei.razãosocial);
    }
    
}
